// Functionality for red heart button
document.getElementById("heartBtn").addEventListener("click", function() {
    document.getElementById("heartBtn").style.display = "none"; // Hide the heart button
    document.getElementById("envelope").classList.remove("hidden"); // Show the envelope
});

// Functionality for "Crush back na nga kita" button
document.getElementById("crushBackBtn").addEventListener("click", function() {
    document.getElementById("heartBtn").style.display = "none"; // Hide the red heart button
    document.querySelector(".clickText").style.display = "none"; // Hide the "Click me" text
    document.getElementById("envelope").classList.add("hidden"); // Hide the envelope
    document.getElementById("sadEmoji").classList.add("hidden"); // Hide the sad emoji
    document.getElementById("walaNangBawianText").classList.remove("hidden"); // Show "Yieehh WALA NANG BAWIAN" text
    // Log the button clicked
    console.log("User chose: Crush back na nga kita");
});

// Functionality for "OK" button
document.getElementById("sigeBtn").addEventListener("click", function() {
    document.getElementById("envelope").classList.add("hidden"); // Hide the envelope
    document.getElementById("sadEmoji").classList.remove("hidden"); // Show the sad emoji
    // Log the button clicked
    console.log("User chose: OK");
});

